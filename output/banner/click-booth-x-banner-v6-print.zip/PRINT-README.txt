AIERA X배너 v6 최종 수정본 (2026-10-28)
일반 PDF 600x1800mm / 재단 여유 PDF 606x1806mm, 사방 3mm
RGB, 글자와 QR 벡터. 인쇄소 지정 규격을 우선합니다.
안동발명교육연구회 왼쪽 정렬, 풍천풍서초 발명동아리 우측 정렬, 같은 글자 크기.
QR: https://3d.aiera.co.kr/home.html (대문)
이 ZIP 안의 aiera-home PDF를 사용하세요. 이전 PDF는 변경 전 이력입니다.
