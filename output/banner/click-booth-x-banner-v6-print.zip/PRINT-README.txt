상상을 클릭하다! X배너 v6 / AIERA 자체 개발 강조
일반 PDF: 완성 600 x 1800 mm.
-bleed3mm.pdf: 사방 3mm 여유, 전체 606 x 1806 mm.
JPG: 150 dpi. RGB. 인쇄소 지정 규격을 우선합니다.
제품 이미지는 실제 STL과 앱 모델링 기반 렌더링입니다.

2026-10-28: Both organization labels use the same font size and right alignment.
