X-banner v3: AIERA / WNL
Standard PDF: 600 x 1800 mm. Bleed PDF: 606 x 1806 mm, 3 mm bleed.
Typography and QR are vector. Product render is an illustration.
RGB colors, no printer-specific CMYK profile.
QR verified against the final JPG.
