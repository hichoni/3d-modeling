600 x 1800 mm X-banner v2
Standard PDF: final size 600 x 1800 mm.
Bleed PDF: 606 x 1806 mm with 3 mm bleed on each edge.
JPG: 3544 x 10630 px, 150 dpi raster export.
Typography and QR are vector in PDF. RGB color, no printer-specific CMYK profile.
QR verified: https://hichoni.github.io/3d-modeling/index.html?start
